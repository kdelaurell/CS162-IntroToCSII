/********************************
 * Author: Kyle De Laurell
 * Date: 2/19/16
 * Description: searchSortFunctions
 * header File
 * *********************************/
#ifndef searchSortFunctions_HPP
#define searchSortFunctions_HPP
#include <fstream>

void searchFile();
void sortFile();
void binarySearchFile();

#endif
